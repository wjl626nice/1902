from wechatpay import WeChatPay
# 公众号凭证
appid = "wx9c0f174d18be9b65"
appsecret = "1dd5b2d9c2f1585a16265f48e5a05482"
mch_id = '1516479061'
notify_url = 'https://rimetleague.com/recharge/callback/'
pay_secret = 'QTcktJ0G1oV4m7AckUynpavT44FbYnDm'
cert = ''
key = ''

WX = WeChatPay(appid, mch_id, notify_url, pay_secret, cert, key)
wx = WeChatPay(appid, mch_id, notify_url, pay_secret)